export type { UserRole, Profile, Product, Order, OrderItem } from './localDB';
import { localAuth, QueryBuilder } from './localDB';

export interface LocalUser {
  id: string;
  email: string;
  created_at?: string;
}

type AuthCallback = (event: string, session: { user: LocalUser } | null) => void;

const authListeners: AuthCallback[] = [];

function notifyListeners(event: string, user: LocalUser | null): void {
  const session = user ? { user } : null;
  authListeners.forEach((cb) => cb(event, session));
}

export const supabase = {
  auth: {
    getSession(): Promise<{ data: { session: { user: LocalUser } | null } }> {
      const data = localAuth.getSession();
      const session = data.user
        ? { user: { id: data.user.id, email: data.user.email } }
        : null;
      return Promise.resolve({ data: { session } });
    },

    onAuthStateChange(
      callback: AuthCallback
    ): { data: { subscription: { unsubscribe: () => void } } } {
      authListeners.push(callback);
      return {
        data: {
          subscription: {
            unsubscribe(): void {
              const idx = authListeners.indexOf(callback);
              if (idx > -1) authListeners.splice(idx, 1);
            },
          },
        },
      };
    },

    async signUp({
      email,
      password,
    }: {
      email: string;
      password: string;
    }): Promise<{ data: { user: LocalUser | null }; error: Error | null }> {
      try {
        const user = localAuth.signUp(email, password);
        const localUser: LocalUser = { id: user.id, email: user.email };
        return { data: { user: localUser }, error: null };
      } catch (e) {
        return { data: { user: null }, error: e as Error };
      }
    },

    async signInWithPassword({
      email,
      password,
    }: {
      email: string;
      password: string;
    }): Promise<{ error: Error | null }> {
      try {
        const user = localAuth.signIn(email, password);
        const localUser: LocalUser = { id: user.id, email: user.email };
        notifyListeners('SIGNED_IN', localUser);
        return { error: null };
      } catch (e) {
        return { error: e as Error };
      }
    },

    async signOut(): Promise<{ error: Error | null }> {
      localAuth.signOut();
      notifyListeners('SIGNED_OUT', null);
      return { error: null };
    },
  },

  from(table: string): QueryBuilder {
    return new QueryBuilder(table);
  },
};

export const isSupabaseConfigured = true;
